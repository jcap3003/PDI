import cv2
import numpy as np
from os import listdir
from os.path import isfile, join

mypath = 'masks/'
onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]


drawing = False # true if mouse is pressed
erasing = False
mode = 'inpaint' # if True, draw rectangle. Press 'm' to toggle to curve
ix,iy = -1,-1
lix, liy = -1, -1
frame = None

# mouse callback function
def draw_circle(event,x,y,flags,param):
    global ix,iy,drawing,mode, lix,liy, erasing

    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
        lix,liy = x, y
        ix,iy = x,y
    if event == cv2.EVENT_RBUTTONDOWN:
        erasing = True
        lix,liy = x, y
        ix,iy = x,y

    elif event == cv2.EVENT_MOUSEMOVE:
        if drawing == True and lix>=0 and liy>=0:
            cv2.line(img,(lix,liy), (ix,iy),255, 3  )
            lix,liy = ix, iy
            ix,iy = x,y
        if erasing == True and lix>=0 and liy>=0:
            cv2.line(img,(lix,liy), (ix,iy),0, 7  )
            lix,liy = ix, iy
            ix,iy = x,y
    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False
        lix, liy = -1, -1
    elif event == cv2.EVENT_RBUTTONUP:
        erasing = False
        lix, liy = -1, -1



name = "CASSETA.mp4"
capture = cv2.VideoCapture('videos/' + name)
capture.set(cv2.CAP_PROP_FPS, 8)

## GETTING MASK
if not 'mask-' +name.split('.')[0] + ".npy" in onlyfiles :
    while frame is None:
        ret, frame = capture.read()

    frame_cp = frame.copy()
    print(frame.shape)
    img = np.zeros(frame.shape[:2] + (1,), np.uint8)
    cv2.namedWindow('image')
    cv2.namedWindow('mask')
    cv2.setMouseCallback('image',draw_circle)
    cv2.setMouseCallback('mask',draw_circle)

    while(1):
        cv2.imshow('image',cv2.bitwise_or(frame, frame_cp, mask=cv2.bitwise_not(img)))
        cv2.imshow('mask', img)
        k = cv2.waitKey(1) & 0xFF
        if k == 27:
            break
    np.save("masks/mask-" + name.split('.')[0] + ".npy", img)

else:
    img = np.load("masks/mask-" + name.split('.')[0] + ".npy")

## SHOWING RESULT
cv2.namedWindow('result')
while(1):
    ret, frame = capture.read()
    if ret == True:
        if mode == 'inpaint':
            inpainted = cv2.inpaint(frame, img, 3, cv2.INPAINT_TELEA)
        else:
            inpainted = frame
        cv2.imshow("result", inpainted)
        k = cv2.waitKey(1) & 0xFF
        if k == 27:
            break
        if k == ord("m"):
            if mode == 'inpaint':
                mode = 'normal'
            else:
                mode = 'inpaint'
        
cv2.destroyAllWindows()